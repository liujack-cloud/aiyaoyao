"""
Agent核心模块
定义所有Agent的基类和通用功能
"""

from abc import ABC, abstractmethod
from enum import Enum
from dataclasses import dataclass, field
from typing import Dict, Any, Optional, List, Callable
from datetime import datetime
import logging
import threading
import time

from core.message import Message, MessageType, MessagePriority, message_bus, MessageBus
from core.config import config_manager


class AgentState(Enum):
    """Agent状态"""
    IDLE = "idle"
    BUSY = "busy"
    ERROR = "error"
    OFFLINE = "offline"


class AgentType(Enum):
    """Agent类型"""
    COORDINATOR = "coordinator"
    EXECUTOR = "executor"
    MONITOR = "monitor"
    REPORTER = "reporter"
    CUSTOM = "custom"


@dataclass
class AgentCapability:
    """Agent能力"""
    name: str
    description: str
    enabled: bool = True


@dataclass
class AgentConfig:
    """Agent配置"""
    id: str
    name: str
    agent_type: AgentType
    capabilities: List[str] = field(default_factory=list)
    max_concurrent_tasks: int = 5
    timeout: int = 300
    metadata: Dict[str, Any] = field(default_factory=dict)


class BaseAgent(ABC):
    """Agent基类"""

    def __init__(self, config: AgentConfig):
        self.config = config
        self.agent_id = config.id
        self.name = config.name
        self.agent_type = config.agent_type
        self.capabilities = config.capabilities
        self.max_concurrent_tasks = config.max_concurrent_tasks
        self.timeout = config.timeout

        self._state = AgentState.IDLE
        self._current_tasks: Dict[str, Any] = {}
        self._message_bus = message_bus
        self._logger = logging.getLogger(f"Agent.{self.agent_id}")
        self._lock = threading.Lock()
        self._running = False
        self._heartbeat_interval = 30
        self._last_heartbeat = datetime.now()

    @property
    def state(self) -> AgentState:
        """获取Agent状态"""
        return self._state

    @state.setter
    def state(self, value: AgentState) -> None:
        """设置Agent状态"""
        self._state = value
        self._logger.info(f"Agent {self.agent_id} state changed to {value.value}")

    def start(self) -> None:
        """启动Agent"""
        self._running = True
        self._message_bus.subscribe(self.agent_id, self._handle_message)
        self._start_heartbeat()
        self._logger.info(f"Agent {self.agent_id} started")

    def stop(self) -> None:
        """停止Agent"""
        self._running = False
        self._logger.info(f"Agent {self.agent_id} stopped")

    def _start_heartbeat(self) -> None:
        """启动心跳"""
        def heartbeat_loop():
            while self._running:
                time.sleep(self._heartbeat_interval)
                self._send_heartbeat()

        thread = threading.Thread(target=heartbeat_loop, daemon=True)
        thread.start()

    def _send_heartbeat(self) -> None:
        """发送心跳"""
        msg = Message(
            msg_type=MessageType.HEARTBEAT,
            sender=self.agent_id,
            receiver="",
            content={
                'state': self._state.value,
                'current_tasks': len(self._current_tasks),
                'timestamp': datetime.now().isoformat()
            }
        )
        self._message_bus.publish(msg)
        self._last_heartbeat = datetime.now()

    def _handle_message(self, message: Message) -> None:
        """处理接收到的消息"""
        self._logger.debug(f"Received message: {message}")

        if message.msg_type == MessageType.TASK:
            self._handle_task(message)
        elif message.msg_type == MessageType.COMMAND:
            self._handle_command(message)
        elif message.msg_type == MessageType.COORDINATION:
            self._handle_coordination(message)

    def _handle_task(self, message: Message) -> None:
        """处理任务消息"""
        task_id = message.content.get('task_id')
        with self._lock:
            if len(self._current_tasks) >= self.max_concurrent_tasks:
                self._send_error(
                    receiver=message.sender,
                    correlation_id=message.msg_id,
                    error="Agent is at maximum capacity"
                )
                return

            self._current_tasks[task_id] = {
                'message': message,
                'start_time': datetime.now(),
                'status': 'processing'
            }

        try:
            result = self.execute_task(message.content)
            self._send_result(message.sender, task_id, result, message.msg_id)
        except Exception as e:
            self._logger.error(f"Task execution error: {e}")
            self._send_error(message.sender, task_id, str(e), message.msg_id)
        finally:
            with self._lock:
                if task_id in self._current_tasks:
                    del self._current_tasks[task_id]

    @abstractmethod
    def execute_task(self, task_data: Dict[str, Any]) -> Any:
        """执行任务 - 子类必须实现"""
        pass

    def _handle_command(self, message: Message) -> None:
        """处理命令消息"""
        command = message.content.get('command')
        if command == 'stop':
            self.stop()
        elif command == 'status':
            self._send_status(message.sender, message.msg_id)
        elif command == 'reload':
            self._handle_reload()

    def _handle_coordination(self, message: Message) -> None:
        """处理协调消息"""
        action = message.content.get('action')
        if action == 'coordinate':
            self.coordinate_with_agents(message)

    def coordinate_with_agents(self, message: Message) -> None:
        """与其他Agent协调"""
        pass

    def _send_result(self, receiver: str, task_id: str, result: Any, correlation_id: str) -> None:
        """发送结果"""
        msg = Message(
            msg_type=MessageType.RESULT,
            sender=self.agent_id,
            receiver=receiver,
            content={
                'task_id': task_id,
                'result': result,
                'status': 'completed'
            },
            correlation_id=correlation_id
        )
        self._message_bus.publish(msg)

    def _send_error(self, receiver: str, task_id: str, error: str, correlation_id: str) -> None:
        """发送错误"""
        msg = Message(
            msg_type=MessageType.ERROR,
            sender=self.agent_id,
            receiver=receiver,
            content={
                'task_id': task_id,
                'error': error,
                'status': 'failed'
            },
            correlation_id=correlation_id
        )
        self._message_bus.publish(msg)

    def _send_status(self, receiver: str, correlation_id: str) -> None:
        """发送状态"""
        msg = Message(
            msg_type=MessageType.STATUS,
            sender=self.agent_id,
            receiver=receiver,
            content={
                'agent_id': self.agent_id,
                'state': self._state.value,
                'current_tasks': len(self._current_tasks),
                'capabilities': self.capabilities
            },
            correlation_id=correlation_id
        )
        self._message_bus.publish(msg)

    def _handle_reload(self) -> None:
        """处理配置重载"""
        self._logger.info("Reloading configuration")

    def send_message(self, receiver: str, msg_type: MessageType, content: Dict[str, Any],
                     priority: MessagePriority = MessagePriority.NORMAL) -> None:
        """发送消息"""
        msg = Message(
            msg_type=msg_type,
            sender=self.agent_id,
            receiver=receiver,
            content=content,
            priority=priority
        )
        self._message_bus.publish(msg)

    def get_status(self) -> Dict[str, Any]:
        """获取Agent状态信息"""
        return {
            'agent_id': self.agent_id,
            'name': self.name,
            'type': self.agent_type.value,
            'state': self._state.value,
            'current_tasks': len(self._current_tasks),
            'max_concurrent_tasks': self.max_concurrent_tasks,
            'capabilities': self.capabilities,
            'last_heartbeat': self._last_heartbeat.isoformat()
        }


class CoordinatorAgent(BaseAgent):
    """协调器Agent - 负责任务协调和工作流管理"""

    def __init__(self, config: AgentConfig):
        super().__init__(config)
        self.active_workflows: Dict[str, Any] = {}

    def execute_task(self, task_data: Dict[str, Any]) -> Any:
        """执行协调任务"""
        task_type = task_data.get('type')
        if task_type == 'coordinate':
            return self._coordinate_task(task_data)
        elif task_type == 'workflow':
            return self._execute_workflow(task_data)
        else:
            return {'status': 'unknown_task_type'}

    def _coordinate_task(self, task_data: Dict[str, Any]) -> Dict[str, Any]:
        """协调任务"""
        target_agents = task_data.get('target_agents', [])
        task = task_data.get('task', {})

        results = []
        for agent_id in target_agents:
            self.send_message(
                receiver=agent_id,
                msg_type=MessageType.TASK,
                content={'task': task, 'coordinator': self.agent_id}
            )
            results.append({'agent_id': agent_id, 'status': 'dispatched'})

        return {
            'status': 'coordinated',
            'dispatched_to': target_agents,
            'results': results
        }

    def _execute_workflow(self, task_data: Dict[str, Any]) -> Dict[str, Any]:
        """执行工作流"""
        workflow_name = task_data.get('workflow_name')
        workflow = config_manager.get_workflow(workflow_name)

        if not workflow:
            return {'status': 'workflow_not_found', 'workflow': workflow_name}

        workflow_id = f"wf_{int(time.time())}"
        self.active_workflows[workflow_id] = {
            'name': workflow_name,
            'status': 'running',
            'start_time': datetime.now()
        }

        return {
            'status': 'workflow_started',
            'workflow_id': workflow_id,
            'workflow_name': workflow_name
        }


class ExecutorAgent(BaseAgent):
    """执行器Agent - 负责具体任务执行"""

    def __init__(self, config: AgentConfig):
        super().__init__(config)

    def execute_task(self, task_data: Dict[str, Any]) -> Any:
        """执行具体任务"""
        task = task_data.get('task', task_data)
        action = task.get('action', 'default')

        if action == 'process':
            return self._process_data(task)
        elif action == 'analyze':
            return self._analyze_data(task)
        elif action == 'transform':
            return self._transform_data(task)
        else:
            return self._default_execution(task)

    def _process_data(self, task: Dict[str, Any]) -> Dict[str, Any]:
        """处理数据"""
        data = task.get('data', [])
        operation = task.get('operation', 'process')

        if operation == 'aggregate':
            result = sum(data) if data else 0
        elif operation == 'filter':
            condition = task.get('condition', lambda x: True)
            result = [x for x in data if condition(x)]
        else:
            result = {'processed': len(data), 'operation': operation}

        return {
            'status': 'completed',
            'result': result,
            'processed_items': len(data)
        }

    def _analyze_data(self, task: Dict[str, Any]) -> Dict[str, Any]:
        """分析数据"""
        data = task.get('data', [])
        return {
            'status': 'analyzed',
            'count': len(data),
            'summary': f"Analyzed {len(data)} items"
        }

    def _transform_data(self, task: Dict[str, Any]) -> Dict[str, Any]:
        """转换数据"""
        data = task.get('data', [])
        transform_type = task.get('transform_type', 'identity')

        return {
            'status': 'transformed',
            'transform_type': transform_type,
            'output_size': len(data)
        }

    def _default_execution(self, task: Dict[str, Any]) -> Dict[str, Any]:
        """默认执行"""
        return {
            'status': 'executed',
            'agent': self.agent_id,
            'task': task
        }


class MonitorAgent(BaseAgent):
    """监控Agent - 负责系统监控和健康检查"""

    def __init__(self, config: AgentConfig):
        super().__init__(config)
        self.check_interval = config.metadata.get('check_interval', 30)
        self._health_history: List[Dict[str, Any]] = []

    def execute_task(self, task_data: Dict[str, Any]) -> Any:
        """执行监控任务"""
        monitor_type = task_data.get('type', 'health_check')

        if monitor_type == 'health_check':
            return self._perform_health_check(task_data)
        elif monitor_type == 'performance':
            return self._check_performance(task_data)
        elif monitor_type == 'alert':
            return self._handle_alert(task_data)
        else:
            return {'status': 'unknown_monitor_type'}

    def _perform_health_check(self, task_data: Dict[str, Any]) -> Dict[str, Any]:
        """执行健康检查"""
        target = task_data.get('target', 'system')

        health_status = {
            'status': 'healthy',
            'target': target,
            'timestamp': datetime.now().isoformat(),
            'checks': {
                'cpu': 'ok',
                'memory': 'ok',
                'disk': 'ok',
                'network': 'ok'
            }
        }

        self._health_history.append(health_status)
        if len(self._health_history) > 100:
            self._health_history = self._health_history[-100:]

        return health_status

    def _check_performance(self, task_data: Dict[str, Any]) -> Dict[str, Any]:
        """检查性能"""
        return {
            'status': 'performance_checked',
            'metrics': {
                'response_time': 120,
                'throughput': 95,
                'error_rate': 0.01
            }
        }

    def _handle_alert(self, task_data: Dict[str, Any]) -> Dict[str, Any]:
        """处理告警"""
        alert_level = task_data.get('level', 'info')
        alert_message = task_data.get('message', '')

        return {
            'status': 'alert_processed',
            'level': alert_level,
            'message': alert_message,
            'action_taken': 'notified'
        }


class ReporterAgent(BaseAgent):
    """报告Agent - 负责生成报告和通知"""

    def __init__(self, config: AgentConfig):
        super().__init__(config)
        self.report_interval = config.metadata.get('report_interval', 60)

    def execute_task(self, task_data: Dict[str, Any]) -> Any:
        """生成报告"""
        report_type = task_data.get('type', 'status')

        if report_type == 'status':
            return self._generate_status_report(task_data)
        elif report_type == 'metrics':
            return self._generate_metrics_report(task_data)
        elif report_type == 'notification':
            return self._send_notification(task_data)
        else:
            return {'status': 'unknown_report_type'}

    def _generate_status_report(self, task_data: Dict[str, Any]) -> Dict[str, Any]:
        """生成状态报告"""
        return {
            'status': 'report_generated',
            'report_type': 'status',
            'timestamp': datetime.now().isoformat(),
            'summary': 'System running normally'
        }

    def _generate_metrics_report(self, task_data: Dict[str, Any]) -> Dict[str, Any]:
        """生成指标报告"""
        return {
            'status': 'report_generated',
            'report_type': 'metrics',
            'timestamp': datetime.now().isoformat(),
            'metrics': {
                'total_tasks': 100,
                'completed_tasks': 95,
                'failed_tasks': 2,
                'pending_tasks': 3
            }
        }

    def _send_notification(self, task_data: Dict[str, Any]) -> Dict[str, Any]:
        """发送通知"""
        recipient = task_data.get('recipient', 'admin')
        message = task_data.get('message', '')

        return {
            'status': 'notification_sent',
            'recipient': recipient,
            'message': message
        }


def create_agent(agent_config: Dict[str, Any]) -> BaseAgent:
    """根据配置创建Agent"""
    agent_id = agent_config.get('id')
    agent_type_str = agent_config.get('type', 'custom')
    agent_type = AgentType(agent_type_str)

    config = AgentConfig(
        id=agent_id,
        name=agent_config.get('name', agent_id),
        agent_type=agent_type,
        capabilities=agent_config.get('capabilities', []),
        max_concurrent_tasks=agent_config.get('config', {}).get('max_concurrent_tasks', 5),
        timeout=agent_config.get('config', {}).get('timeout', 300),
        metadata=agent_config.get('config', {})
    )

    if agent_type == AgentType.COORDINATOR:
        return CoordinatorAgent(config)
    elif agent_type == AgentType.EXECUTOR:
        return ExecutorAgent(config)
    elif agent_type == AgentType.MONITOR:
        return MonitorAgent(config)
    elif agent_type == AgentType.REPORTER:
        return ReporterAgent(config)
    else:
        return BaseAgent(config)
