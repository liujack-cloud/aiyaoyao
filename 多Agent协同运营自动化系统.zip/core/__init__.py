"""
Core模块 - 多Agent系统的核心组件
"""

from core.config import ConfigManager, config_manager
from core.message import (
    Message, MessageType, MessagePriority,
    MessageBus, message_bus
)
from core.agent import (
    BaseAgent, AgentState, AgentType, AgentConfig,
    CoordinatorAgent, ExecutorAgent, MonitorAgent, ReporterAgent,
    create_agent
)

__all__ = [
    'ConfigManager', 'config_manager',
    'Message', 'MessageType', 'MessagePriority', 'MessageBus', 'message_bus',
    'BaseAgent', 'AgentState', 'AgentType', 'AgentConfig',
    'CoordinatorAgent', 'ExecutorAgent', 'MonitorAgent', 'ReporterAgent',
    'create_agent'
]
