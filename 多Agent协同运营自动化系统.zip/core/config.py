"""
配置管理模块
处理系统配置加载和访问
"""

import yaml
from pathlib import Path
from typing import Dict, Any, Optional
import logging

logger = logging.getLogger(__name__)


class ConfigManager:
    """配置管理器"""

    def __init__(self, config_path: str = "config.yaml"):
        self.config_path = Path(config_path)
        self._config: Optional[Dict[str, Any]] = None
        self.load_config()

    def load_config(self) -> None:
        """加载配置文件"""
        try:
            if self.config_path.exists():
                with open(self.config_path, 'r', encoding='utf-8') as f:
                    self._config = yaml.safe_load(f)
                logger.info(f"Configuration loaded from {self.config_path}")
            else:
                logger.warning(f"Config file not found: {self.config_path}, using defaults")
                self._config = self._get_default_config()
        except Exception as e:
            logger.error(f"Failed to load config: {e}")
            self._config = self._get_default_config()

    def _get_default_config(self) -> Dict[str, Any]:
        """获取默认配置"""
        return {
            'system': {
                'name': 'Multi-Agent System',
                'version': '1.0.0',
                'log_level': 'INFO'
            },
            'server': {
                'host': '0.0.0.0',
                'port': 5000
            },
            'agents': [],
            'workflows': {},
            'scheduling': {
                'max_concurrent_tasks': 20,
                'task_timeout': 3600,
                'retry_attempts': 3
            }
        }

    @property
    def config(self) -> Dict[str, Any]:
        """获取完整配置"""
        return self._config

    def get(self, key: str, default: Any = None) -> Any:
        """获取配置项"""
        keys = key.split('.')
        value = self._config
        for k in keys:
            if isinstance(value, dict):
                value = value.get(k)
                if value is None:
                    return default
            else:
                return default
        return value

    def get_agents(self) -> list:
        """获取Agent配置列表"""
        return self.get('agents', [])

    def get_agent_config(self, agent_id: str) -> Optional[Dict[str, Any]]:
        """获取指定Agent的配置"""
        agents = self.get_agents()
        for agent in agents:
            if agent.get('id') == agent_id:
                return agent
        return None

    def get_workflows(self) -> Dict[str, Any]:
        """获取工作流配置"""
        return self.get('workflows', {})

    def get_workflow(self, workflow_name: str) -> Optional[Dict[str, Any]]:
        """获取指定工作流配置"""
        workflows = self.get_workflows()
        return workflows.get(workflow_name)

    def get_scheduling_config(self) -> Dict[str, Any]:
        """获取调度配置"""
        return self.get('scheduling', {})


config_manager = ConfigManager()
