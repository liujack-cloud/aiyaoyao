"""
消息和通信机制模块
定义Agent之间的消息传递机制
"""

from enum import Enum
from dataclasses import dataclass, field
from typing import Dict, Any, Optional, List
from datetime import datetime
import uuid
import json


class MessageType(Enum):
    """消息类型"""
    TASK = "task"
    RESULT = "result"
    STATUS = "status"
    ERROR = "error"
    HEARTBEAT = "heartbeat"
    COMMAND = "command"
    NOTIFICATION = "notification"
    COORDINATION = "coordination"


class MessagePriority(Enum):
    """消息优先级"""
    LOW = 1
    NORMAL = 2
    HIGH = 3
    URGENT = 4


@dataclass
class Message:
    """消息基类"""
    msg_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    msg_type: MessageType = MessageType.TASK
    sender: str = ""
    receiver: str = ""
    content: Dict[str, Any] = field(default_factory=dict)
    priority: MessagePriority = MessagePriority.NORMAL
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())
    correlation_id: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            'msg_id': self.msg_id,
            'msg_type': self.msg_type.value if isinstance(self.msg_type, MessageType) else self.msg_type,
            'sender': self.sender,
            'receiver': self.receiver,
            'content': self.content,
            'priority': self.priority.value if isinstance(self.priority, MessagePriority) else self.priority,
            'timestamp': self.timestamp,
            'correlation_id': self.correlation_id,
            'metadata': self.metadata
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Message':
        """从字典创建消息"""
        msg_type = data.get('msg_type')
        if isinstance(msg_type, str):
            msg_type = MessageType(msg_type)

        priority = data.get('priority')
        if isinstance(priority, int):
            priority = MessagePriority(priority)

        return cls(
            msg_id=data.get('msg_id', str(uuid.uuid4())),
            msg_type=msg_type or MessageType.TASK,
            sender=data.get('sender', ''),
            receiver=data.get('receiver', ''),
            content=data.get('content', {}),
            priority=priority or MessagePriority.NORMAL,
            timestamp=data.get('timestamp', datetime.now().isoformat()),
            correlation_id=data.get('correlation_id'),
            metadata=data.get('metadata', {})
        )

    def __str__(self) -> str:
        return f"Message({self.msg_id}, {self.msg_type.value}, {self.sender} -> {self.receiver})"


@dataclass
class TaskMessage(Message):
    """任务消息"""
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.msg_type = MessageType.TASK


@dataclass
class ResultMessage(Message):
    """结果消息"""
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.msg_type = MessageType.RESULT


@dataclass
class StatusMessage(Message):
    """状态消息"""
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.msg_type = MessageType.STATUS


class MessageBus:
    """消息总线 - Agent间通信的核心"""

    def __init__(self):
        self._subscribers: Dict[str, List] = {}
        self._message_queue: List[Message] = []
        self._history: List[Message] = []
        self._max_history = 1000

    def subscribe(self, agent_id: str, callback) -> None:
        """订阅消息"""
        if agent_id not in self._subscribers:
            self._subscribers[agent_id] = []
        self._subscribers[agent_id].append(callback)

    def unsubscribe(self, agent_id: str, callback) -> None:
        """取消订阅"""
        if agent_id in self._subscribers:
            self._subscribers[agent_id] = [
                cb for cb in self._subscribers[agent_id] if cb != callback
            ]

    def publish(self, message: Message) -> None:
        """发布消息"""
        self._message_queue.append(message)
        self._add_to_history(message)
        self._deliver_message(message)

    def _deliver_message(self, message: Message) -> None:
        """投递消息到订阅者"""
        if message.receiver and message.receiver in self._subscribers:
            for callback in self._subscribers[message.receiver]:
                try:
                    callback(message)
                except Exception as e:
                    print(f"Error delivering message: {e}")

        if not message.receiver:
            for agent_id, callbacks in self._subscribers.items():
                if agent_id != message.sender:
                    for callback in callbacks:
                        try:
                            callback(message)
                        except Exception as e:
                            print(f"Error broadcasting message: {e}")

    def _add_to_history(self, message: Message) -> None:
        """添加消息到历史记录"""
        self._history.append(message)
        if len(self._history) > self._max_history:
            self._history = self._history[-self._max_history:]

    def get_messages_for_agent(self, agent_id: str, limit: int = 100) -> List[Message]:
        """获取发送给特定Agent的消息"""
        messages = [
            msg for msg in self._history
            if msg.receiver == agent_id or msg.receiver == ""
        ]
        return messages[-limit:]

    def get_messages_by_type(self, msg_type: MessageType, limit: int = 100) -> List[Message]:
        """按类型获取消息"""
        messages = [
            msg for msg in self._history
            if msg.msg_type == msg_type
        ]
        return messages[-limit:]

    def clear_queue(self) -> None:
        """清空消息队列"""
        self._message_queue.clear()


message_bus = MessageBus()
