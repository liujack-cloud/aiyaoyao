"""
任务调度模块
负责任务的创建、分配、调度和执行
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, Any, Optional, List, Callable
from datetime import datetime, timedelta
import uuid
import logging
import threading
import time
from queue import PriorityQueue, Empty

from core.message import Message, MessageType, MessagePriority, message_bus


class TaskStatus(Enum):
    """任务状态"""
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"
    TIMEOUT = "timeout"


class TaskPriority(Enum):
    """任务优先级"""
    LOW = 1
    NORMAL = 2
    HIGH = 3
    URGENT = 4


@dataclass
class Task:
    """任务定义"""
    task_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    name: str = ""
    description: str = ""
    task_type: str = "general"
    priority: TaskPriority = TaskPriority.NORMAL
    status: TaskStatus = TaskStatus.PENDING
    assigned_agent: Optional[str] = None
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    started_at: Optional[str] = None
    completed_at: Optional[str] = None
    timeout: int = 3600
    retry_count: int = 0
    max_retries: int = 3
    input_data: Dict[str, Any] = field(default_factory=dict)
    output_data: Optional[Dict[str, Any]] = None
    error: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            'task_id': self.task_id,
            'name': self.name,
            'description': self.description,
            'task_type': self.task_type,
            'priority': self.priority.value if isinstance(self.priority, TaskPriority) else self.priority,
            'status': self.status.value if isinstance(self.status, TaskStatus) else self.status,
            'assigned_agent': self.assigned_agent,
            'created_at': self.created_at,
            'started_at': self.started_at,
            'completed_at': self.completed_at,
            'timeout': self.timeout,
            'retry_count': self.retry_count,
            'max_retries': self.max_retries,
            'input_data': self.input_data,
            'output_data': self.output_data,
            'error': self.error,
            'metadata': self.metadata
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Task':
        """从字典创建任务"""
        priority = data.get('priority', 2)
        if isinstance(priority, int):
            priority = TaskPriority(priority)

        status = data.get('status', 'pending')
        if isinstance(status, str):
            status = TaskStatus(status)

        return cls(
            task_id=data.get('task_id', str(uuid.uuid4())),
            name=data.get('name', ''),
            description=data.get('description', ''),
            task_type=data.get('task_type', 'general'),
            priority=priority,
            status=status,
            assigned_agent=data.get('assigned_agent'),
            created_at=data.get('created_at', datetime.now().isoformat()),
            started_at=data.get('started_at'),
            completed_at=data.get('completed_at'),
            timeout=data.get('timeout', 3600),
            retry_count=data.get('retry_count', 0),
            max_retries=data.get('max_retries', 3),
            input_data=data.get('input_data', {}),
            output_data=data.get('output_data'),
            error=data.get('error'),
            metadata=data.get('metadata', {})
        )


class TaskScheduler:
    """任务调度器"""

    def __init__(self, max_concurrent_tasks: int = 20):
        self.max_concurrent_tasks = max_concurrent_tasks
        self._tasks: Dict[str, Task] = {}
        self._task_queue = PriorityQueue()
        self._running_tasks: Dict[str, Task] = {}
        self._lock = threading.Lock()
        self._scheduler_running = False
        self._logger = logging.getLogger("TaskScheduler")

    def start(self) -> None:
        """启动调度器"""
        self._scheduler_running = True
        self._start_dispatch_loop()
        self._start_timeout_checker()
        self._logger.info("Task scheduler started")

    def stop(self) -> None:
        """停止调度器"""
        self._scheduler_running = False
        self._logger.info("Task scheduler stopped")

    def _start_dispatch_loop(self) -> None:
        """启动任务分发循环"""
        def dispatch_loop():
            while self._scheduler_running:
                self._dispatch_tasks()
                time.sleep(0.1)

        thread = threading.Thread(target=dispatch_loop, daemon=True)
        thread.start()

    def _start_timeout_checker(self) -> None:
        """启动超时检查器"""
        def timeout_checker():
            while self._scheduler_running:
                self._check_timeouts()
                time.sleep(1)

        thread = threading.Thread(target=timeout_checker, daemon=True)
        thread.start()

    def _dispatch_tasks(self) -> None:
        """分发任务"""
        with self._lock:
            if len(self._running_tasks) >= self.max_concurrent_tasks:
                return

            try:
                while len(self._running_tasks) < self.max_concurrent_tasks:
                    priority, task_id = self._task_queue.get_nowait()

                    if task_id not in self._tasks:
                        continue

                    task = self._tasks[task_id]
                    if task.status != TaskStatus.PENDING:
                        continue

                    task.status = TaskStatus.RUNNING
                    task.started_at = datetime.now().isoformat()
                    self._running_tasks[task_id] = task

                    self._dispatch_to_agent(task)

            except Empty:
                pass

    def _dispatch_to_agent(self, task: Task) -> None:
        """分发任务到Agent"""
        if task.assigned_agent:
            msg = Message(
                msg_type=MessageType.TASK,
                sender="scheduler",
                receiver=task.assigned_agent,
                content={
                    'task_id': task.task_id,
                    'task': task.input_data,
                    'timeout': task.timeout
                }
            )
            message_bus.publish(msg)
        else:
            msg = Message(
                msg_type=MessageType.TASK,
                sender="scheduler",
                receiver="",
                content={
                    'task_id': task.task_id,
                    'task': task.input_data,
                    'timeout': task.timeout
                }
            )
            message_bus.publish(msg)

    def _check_timeouts(self) -> None:
        """检查任务超时"""
        with self._lock:
            current_time = datetime.now()
            for task_id, task in list(self._running_tasks.items()):
                if task.started_at:
                    start_time = datetime.fromisoformat(task.started_at)
                    if (current_time - start_time).total_seconds() > task.timeout:
                        self._handle_task_timeout(task)

    def _handle_task_timeout(self, task: Task) -> None:
        """处理任务超时"""
        self._logger.warning(f"Task {task.task_id} timed out")
        task.status = TaskStatus.TIMEOUT
        task.error = "Task execution timeout"

        if task_id := task.task_id in self._running_tasks:
            del self._running_tasks[task_id]

        if task.retry_count < task.max_retries:
            self._retry_task(task)
        else:
            self._fail_task(task)

    def _retry_task(self, task: Task) -> None:
        """重试任务"""
        task.retry_count += 1
        task.status = TaskStatus.PENDING
        self.add_task(task)

    def _fail_task(self, task: Task) -> None:
        """标记任务失败"""
        task.status = TaskStatus.FAILED

    def add_task(self, task: Task) -> str:
        """添加任务"""
        with self._lock:
            self._tasks[task.task_id] = task
            priority = task.priority.value if isinstance(task.priority, TaskPriority) else 2
            self._task_queue.put((priority, task.task_id))

        self._logger.info(f"Task added: {task.task_id}")
        return task.task_id

    def create_task(self, name: str, task_type: str, input_data: Dict[str, Any],
                   priority: TaskPriority = TaskPriority.NORMAL,
                   assigned_agent: Optional[str] = None,
                   timeout: int = 3600) -> str:
        """创建新任务"""
        task = Task(
            name=name,
            task_type=task_type,
            priority=priority,
            assigned_agent=assigned_agent,
            input_data=input_data,
            timeout=timeout
        )
        return self.add_task(task)

    def get_task(self, task_id: str) -> Optional[Task]:
        """获取任务"""
        return self._tasks.get(task_id)

    def get_tasks_by_status(self, status: TaskStatus) -> List[Task]:
        """按状态获取任务"""
        return [t for t in self._tasks.values() if t.status == status]

    def get_tasks_by_agent(self, agent_id: str) -> List[Task]:
        """获取分配给特定Agent的任务"""
        return [t for t in self._tasks.values() if t.assigned_agent == agent_id]

    def cancel_task(self, task_id: str) -> bool:
        """取消任务"""
        with self._lock:
            if task_id in self._tasks:
                task = self._tasks[task_id]
                if task.status == TaskStatus.PENDING:
                    task.status = TaskStatus.CANCELLED
                    return True
        return False

    def complete_task(self, task_id: str, result: Dict[str, Any]) -> None:
        """完成任务"""
        with self._lock:
            if task_id in self._running_tasks:
                task = self._running_tasks[task_id]
                task.status = TaskStatus.COMPLETED
                task.completed_at = datetime.now().isoformat()
                task.output_data = result
                del self._running_tasks[task_id]
                self._logger.info(f"Task completed: {task_id}")

    def fail_task(self, task_id: str, error: str) -> None:
        """标记任务失败"""
        with self._lock:
            if task_id in self._running_tasks:
                task = self._running_tasks[task_id]
                task.status = TaskStatus.FAILED
                task.completed_at = datetime.now().isoformat()
                task.error = error
                del self._running_tasks[task_id]
                self._logger.error(f"Task failed: {task_id} - {error}")

    def get_statistics(self) -> Dict[str, Any]:
        """获取调度统计"""
        with self._lock:
            total = len(self._tasks)
            pending = len([t for t in self._tasks.values() if t.status == TaskStatus.PENDING])
            running = len(self._running_tasks)
            completed = len([t for t in self._tasks.values() if t.status == TaskStatus.COMPLETED])
            failed = len([t for t in self._tasks.values() if t.status == TaskStatus.FAILED])

            return {
                'total_tasks': total,
                'pending_tasks': pending,
                'running_tasks': running,
                'completed_tasks': completed,
                'failed_tasks': failed,
                'max_concurrent': self.max_concurrent_tasks
            }


task_scheduler = TaskScheduler()
