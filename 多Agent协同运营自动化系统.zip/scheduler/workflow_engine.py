"""
协同工作流引擎模块
定义和管理复杂的多Agent协同工作流程
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, Any, Optional, List, Callable
from datetime import datetime
import uuid
import logging
import threading
import time

from core.message import Message, MessageType, message_bus
from core.agent import BaseAgent


class WorkflowStatus(Enum):
    """工作流状态"""
    CREATED = "created"
    RUNNING = "running"
    PAUSED = "paused"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class StepStatus(Enum):
    """步骤状态"""
    PENDING = "pending"
    WAITING = "waiting"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    SKIPPED = "skipped"


@dataclass
class WorkflowStep:
    """工作流步骤"""
    step_id: str
    agent_id: str
    action: str
    next_step: Optional[str] = None
    condition: Optional[str] = None
    timeout: int = 300
    retry_count: int = 0
    status: StepStatus = StepStatus.PENDING
    start_time: Optional[str] = None
    end_time: Optional[str] = None
    result: Optional[Dict[str, Any]] = None
    error: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            'step_id': self.step_id,
            'agent_id': self.agent_id,
            'action': self.action,
            'next_step': self.next_step,
            'condition': self.condition,
            'timeout': self.timeout,
            'retry_count': self.retry_count,
            'status': self.status.value if isinstance(self.status, StepStatus) else self.status,
            'start_time': self.start_time,
            'end_time': self.end_time,
            'result': self.result,
            'error': self.error
        }


@dataclass
class Workflow:
    """工作流定义"""
    workflow_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    name: str = ""
    description: str = ""
    status: WorkflowStatus = WorkflowStatus.CREATED
    steps: Dict[str, WorkflowStep] = field(default_factory=dict)
    current_step: Optional[str] = None
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    started_at: Optional[str] = None
    completed_at: Optional[str] = None
    context: Dict[str, Any] = field(default_factory=dict)
    results: Dict[str, Any] = field(default_factory=dict)
    error: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            'workflow_id': self.workflow_id,
            'name': self.name,
            'description': self.description,
            'status': self.status.value if isinstance(self.status, WorkflowStatus) else self.status,
            'steps': {k: v.to_dict() for k, v in self.steps.items()},
            'current_step': self.current_step,
            'created_at': self.created_at,
            'started_at': self.started_at,
            'completed_at': self.completed_at,
            'context': self.context,
            'results': self.results,
            'error': self.error,
            'metadata': self.metadata
        }


class WorkflowEngine:
    """协同工作流引擎"""

    def __init__(self):
        self._workflows: Dict[str, Workflow] = {}
        self._lock = threading.Lock()
        self._running = False
        self._logger = logging.getLogger("WorkflowEngine")
        self._step_handlers: Dict[str, Callable] = {}
        self._message_handlers_setup = False

    def start(self) -> None:
        """启动工作流引擎"""
        self._running = True
        self._setup_message_handlers()
        self._logger.info("Workflow engine started")

    def stop(self) -> None:
        """停止工作流引擎"""
        self._running = False
        self._logger.info("Workflow engine stopped")

    def _setup_message_handlers(self) -> None:
        """设置消息处理器"""
        if not self._message_handlers_setup:
            message_bus.subscribe("workflow_engine", self._handle_result_message)
            self._message_handlers_setup = True

    def _handle_result_message(self, message: Message) -> None:
        """处理结果消息"""
        if message.msg_type == MessageType.RESULT:
            correlation_id = message.correlation_id
            if correlation_id and correlation_id.startswith("wf_"):
                workflow_id = correlation_id
                self._complete_workflow_step(workflow_id, message.content)

    def create_workflow(self, name: str, description: str = "",
                       steps: Optional[List[Dict[str, Any]]] = None) -> Workflow:
        """创建工作流"""
        workflow = Workflow(
            name=name,
            description=description
        )

        if steps:
            for i, step_config in enumerate(steps):
                step_id = step_config.get('step_id') or f"step_{i}"
                step = WorkflowStep(
                    step_id=step_id,
                    agent_id=step_config.get('agent', ''),
                    action=step_config.get('action', ''),
                    next_step=step_config.get('next'),
                    condition=step_config.get('condition'),
                    timeout=step_config.get('timeout', 300)
                )
                workflow.steps[step_id] = step

        with self._lock:
            self._workflows[workflow.workflow_id] = workflow

        self._logger.info(f"Workflow created: {workflow.workflow_id}")
        return workflow

    def start_workflow(self, workflow_id: str, context: Optional[Dict[str, Any]] = None) -> bool:
        """启动工作流"""
        with self._lock:
            if workflow_id not in self._workflows:
                self._logger.error(f"Workflow not found: {workflow_id}")
                return False

            workflow = self._workflows[workflow_id]

            if workflow.status not in [WorkflowStatus.CREATED, WorkflowStatus.PAUSED]:
                self._logger.error(f"Cannot start workflow in status: {workflow.status}")
                return False

            workflow.status = WorkflowStatus.RUNNING
            workflow.started_at = datetime.now().isoformat()
            if context:
                workflow.context.update(context)

            first_step = self._get_first_step(workflow)
            if first_step:
                self._execute_step(workflow, first_step)
            else:
                workflow.status = WorkflowStatus.COMPLETED
                workflow.completed_at = datetime.now().isoformat()

        self._logger.info(f"Workflow started: {workflow_id}")
        return True

    def _get_first_step(self, workflow: Workflow) -> Optional[str]:
        """获取第一个步骤"""
        if not workflow.steps:
            return None

        for step_id, step in workflow.steps.items():
            if step.status == StepStatus.PENDING:
                return step_id

        return None

    def _get_next_step(self, workflow: Workflow, current_step_id: str) -> Optional[str]:
        """获取下一个步骤"""
        current_step = workflow.steps.get(current_step_id)
        if not current_step:
            return None

        next_step_id = current_step.next_step
        if not next_step_id:
            return None

        if next_step_id not in workflow.steps:
            return None

        next_step = workflow.steps[next_step_id]
        if next_step.status != StepStatus.PENDING:
            return None

        return next_step_id

    def _execute_step(self, workflow: Workflow, step_id: str) -> None:
        """执行工作流步骤"""
        step = workflow.steps[step_id]
        step.status = StepStatus.RUNNING
        step.start_time = datetime.now().isoformat()
        workflow.current_step = step_id

        msg = Message(
            msg_type=MessageType.TASK,
            sender="workflow_engine",
            receiver=step.agent_id,
            content={
                'action': step.action,
                'context': workflow.context,
                'step_id': step_id
            },
            correlation_id=workflow.workflow_id
        )
        message_bus.publish(msg)

        self._logger.info(f"Executing workflow step: {step_id} on {step.agent_id}")

    def _complete_workflow_step(self, workflow_id: str, result: Dict[str, Any]) -> None:
        """完成工作流步骤"""
        with self._lock:
            if workflow_id not in self._workflows:
                return

            workflow = self._workflows[workflow_id]
            current_step_id = workflow.current_step

            if not current_step_id or current_step_id not in workflow.steps:
                return

            step = workflow.steps[current_step_id]
            step.status = StepStatus.COMPLETED
            step.end_time = datetime.now().isoformat()
            step.result = result
            workflow.results[current_step_id] = result

            next_step_id = self._get_next_step(workflow, current_step_id)
            if next_step_id:
                self._execute_step(workflow, next_step_id)
            else:
                workflow.status = WorkflowStatus.COMPLETED
                workflow.completed_at = datetime.now().isoformat()
                self._logger.info(f"Workflow completed: {workflow_id}")

    def pause_workflow(self, workflow_id: str) -> bool:
        """暂停工作流"""
        with self._lock:
            if workflow_id not in self._workflows:
                return False

            workflow = self._workflows[workflow_id]
            if workflow.status == WorkflowStatus.RUNNING:
                workflow.status = WorkflowStatus.PAUSED
                self._logger.info(f"Workflow paused: {workflow_id}")
                return True

        return False

    def cancel_workflow(self, workflow_id: str) -> bool:
        """取消工作流"""
        with self._lock:
            if workflow_id not in self._workflows:
                return False

            workflow = self._workflows[workflow_id]
            workflow.status = WorkflowStatus.CANCELLED
            workflow.completed_at = datetime.now().isoformat()
            self._logger.info(f"Workflow cancelled: {workflow_id}")

        return True

    def get_workflow(self, workflow_id: str) -> Optional[Workflow]:
        """获取工作流"""
        return self._workflows.get(workflow_id)

    def get_workflows_by_status(self, status: WorkflowStatus) -> List[Workflow]:
        """按状态获取工作流"""
        return [w for w in self._workflows.values() if w.status == status]

    def register_step_handler(self, action: str, handler: Callable) -> None:
        """注册步骤处理器"""
        self._step_handlers[action] = handler

    def get_statistics(self) -> Dict[str, Any]:
        """获取工作流统计"""
        with self._lock:
            total = len(self._workflows)
            running = len([w for w in self._workflows.values() if w.status == WorkflowStatus.RUNNING])
            completed = len([w for w in self._workflows.values() if w.status == WorkflowStatus.COMPLETED])
            failed = len([w for w in self._workflows.values() if w.status == WorkflowStatus.FAILED])

            return {
                'total_workflows': total,
                'running_workflows': running,
                'completed_workflows': completed,
                'failed_workflows': failed
            }


workflow_engine = WorkflowEngine()
