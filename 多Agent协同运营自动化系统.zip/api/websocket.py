"""
WebSocket通信层
提供实时双向通信能力
"""

from flask_socketio import SocketIO, emit, join_room, leave_room
from typing import Dict, Any
import logging

from core.message import message_bus, Message

socketio = SocketIO(cors_allowed_origins="*", async_mode='eventlet')
logger = logging.getLogger("WebSocket")


class WebSocketManager:
    """WebSocket管理器"""

    def __init__(self, socketio_instance: SocketIO):
        self._socketio = socketio_instance
        self._rooms: Dict[str, set] = {}
        self._message_handlers = []

    def init_app(self, app):
        """初始化应用"""
        self._socketio.init_app(app)

    def broadcast_message(self, event: str, data: Dict[str, Any]) -> None:
        """广播消息"""
        self._socketio.emit(event, data, broadcast=True)

    def send_to_room(self, room: str, event: str, data: Dict[str, Any]) -> None:
        """发送到房间"""
        self._socketio.emit(event, data, room=room)

    def send_to_user(self, sid: str, event: str, data: Dict[str, Any]) -> None:
        """发送给用户"""
        self._socketio.emit(event, data, room=sid)

    def join_room(self, room: str, sid: str) -> None:
        """加入房间"""
        join_room(room, sid=sid)
        if room not in self._rooms:
            self._rooms[room] = set()
        self._rooms[room].add(sid)

    def leave_room(self, room: str, sid: str) -> None:
        """离开房间"""
        leave_room(room, sid=sid)
        if room in self._rooms:
            self._rooms[room].discard(sid)


ws_manager = WebSocketManager(socketio)


def setup_websocket_handlers():
    """设置WebSocket处理器"""

    @socketio.on('connect')
    def handle_connect():
        """处理连接"""
        logger.info(f"Client connected: {sid}")
        emit('connected', {'status': 'connected', 'sid': sid})

    @socketio.on('disconnect')
    def handle_disconnect():
        """处理断开连接"""
        logger.info(f"Client disconnected: {sid}")

    @socketio.on('subscribe')
    def handle_subscribe(data):
        """处理订阅"""
        room = data.get('room')
        if room:
            join_room(room)
            emit('subscribed', {'room': room})
            logger.info(f"Client {sid} subscribed to room {room}")

    @socketio.on('unsubscribe')
    def handle_unsubscribe(data):
        """处理取消订阅"""
        room = data.get('room')
        if room:
            leave_room(room)
            emit('unsubscribed', {'room': room})
            logger.info(f"Client {sid} unsubscribed from room {room}")

    @socketio.on('message')
    def handle_message(data):
        """处理消息"""
        msg_type = data.get('type', 'chat')
        content = data.get('content', {})

        if msg_type == 'agent_command':
            _handle_agent_command(content)
        elif msg_type == 'task_update':
            _handle_task_update(content)
        elif msg_type == 'workflow_control':
            _handle_workflow_control(content)

        emit('message_received', {'status': 'received'})

    @socketio.on('agent_command')
    def handle_agent_command(data):
        """处理Agent命令"""
        _handle_agent_command(data)

    @socketio.on('task_command')
    def handle_task_command(data):
        """处理任务命令"""
        _handle_task_update(data)


def _handle_agent_command(data: Dict[str, Any]):
    """处理Agent命令"""
    agent_id = data.get('agent_id')
    command = data.get('command')
    params = data.get('params', {})

    from core.message import Message, MessageType

    msg = Message(
        msg_type=MessageType.COMMAND,
        sender='websocket_client',
        receiver=agent_id,
        content={
            'command': command,
            'params': params
        }
    )
    message_bus.publish(msg)

    ws_manager.broadcast_message('agent_command_response', {
        'status': 'command_sent',
        'agent_id': agent_id,
        'command': command
    })


def _handle_task_update(data: Dict[str, Any]):
    """处理任务更新"""
    task_id = data.get('task_id')
    action = data.get('action')

    from scheduler import task_scheduler

    if action == 'cancel':
        task_scheduler.cancel_task(task_id)

    ws_manager.broadcast_message('task_update_response', {
        'status': 'updated',
        'task_id': task_id,
        'action': action
    })


def _handle_workflow_control(data: Dict[str, Any]):
    """处理工作流控制"""
    workflow_id = data.get('workflow_id')
    action = data.get('action')

    from scheduler import workflow_engine

    if action == 'start':
        workflow_engine.start_workflow(workflow_id)
    elif action == 'pause':
        workflow_engine.pause_workflow(workflow_id)
    elif action == 'cancel':
        workflow_engine.cancel_workflow(workflow_id)

    ws_manager.broadcast_message('workflow_control_response', {
        'status': 'controlled',
        'workflow_id': workflow_id,
        'action': action
    })


def notify_agent_status(agent_id: str, status: str):
    """通知Agent状态变化"""
    ws_manager.broadcast_message('agent_status_change', {
        'agent_id': agent_id,
        'status': status
    })


def notify_task_update(task_id: str, status: str, result: Any = None):
    """通知任务更新"""
    ws_manager.broadcast_message('task_update', {
        'task_id': task_id,
        'status': status,
        'result': result
    })


def notify_workflow_update(workflow_id: str, status: str, step: str = None):
    """通知工作流更新"""
    ws_manager.broadcast_message('workflow_update', {
        'workflow_id': workflow_id,
        'status': status,
        'current_step': step
    })


def notify_alert(level: str, message: str, source: str = ""):
    """通知告警"""
    ws_manager.broadcast_message('alert', {
        'level': level,
        'message': message,
        'source': source
    })
