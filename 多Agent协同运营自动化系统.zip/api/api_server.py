"""
REST API接口层
提供HTTP接口用于与多Agent系统交互
"""

from flask import Flask, request, jsonify
from typing import Dict, Any
import logging
import uuid

from core import config_manager, message_bus, create_agent
from core.agent import AgentState
from scheduler import task_scheduler, workflow_engine, TaskPriority
from state import state_manager, agent_registry, system_monitor, event_logger

app = Flask(__name__)
logger = logging.getLogger("API")


@app.route('/api/health', methods=['GET'])
def health_check():
    """健康检查接口"""
    return jsonify({
        'status': 'healthy',
        'timestamp': str(uuid.uuid4())
    })


@app.route('/api/agents', methods=['GET'])
def list_agents():
    """获取所有Agent列表"""
    agents = agent_registry.get_all_agents()
    return jsonify({
        'agents': agents,
        'total': len(agents)
    })


@app.route('/api/agents/<agent_id>', methods=['GET'])
def get_agent(agent_id: str):
    """获取指定Agent信息"""
    agent = agent_registry.get_agent(agent_id)
    if not agent:
        return jsonify({'error': 'Agent not found'}), 404

    return jsonify(agent)


@app.route('/api/agents/<agent_id>/status', methods=['GET'])
def get_agent_status(agent_id: str):
    """获取Agent状态"""
    agent = agent_registry.get_agent(agent_id)
    if not agent:
        return jsonify({'error': 'Agent not found'}), 404

    return jsonify({
        'agent_id': agent_id,
        'state': agent.get('state', 'unknown'),
        'last_seen': agent.get('last_seen'),
        'registered_at': agent.get('registered_at')
    })


@app.route('/api/tasks', methods=['POST'])
def create_task():
    """创建新任务"""
    data = request.get_json()

    if not data:
        return jsonify({'error': 'No data provided'}), 400

    name = data.get('name', 'Unnamed Task')
    task_type = data.get('type', 'general')
    input_data = data.get('input_data', {})
    priority = data.get('priority', 2)
    assigned_agent = data.get('assigned_agent')
    timeout = data.get('timeout', 3600)

    task_id = task_scheduler.create_task(
        name=name,
        task_type=task_type,
        input_data=input_data,
        priority=TaskPriority(priority),
        assigned_agent=assigned_agent,
        timeout=timeout
    )

    event_logger.log_event('task_created', f'Task {task_id} created', 'api')

    return jsonify({
        'task_id': task_id,
        'status': 'created'
    }), 201


@app.route('/api/tasks', methods=['GET'])
def list_tasks():
    """获取任务列表"""
    status = request.args.get('status')
    agent_id = request.args.get('agent_id')

    if status:
        tasks = task_scheduler.get_tasks_by_status(status)
    elif agent_id:
        tasks = task_scheduler.get_tasks_by_agent(agent_id)
    else:
        all_tasks = list(task_scheduler._tasks.values())
        tasks = [t.to_dict() for t in all_tasks]

    return jsonify({
        'tasks': [t.to_dict() if hasattr(t, 'to_dict') else t for t in tasks],
        'total': len(tasks)
    })


@app.route('/api/tasks/<task_id>', methods=['GET'])
def get_task(task_id: str):
    """获取任务详情"""
    task = task_scheduler.get_task(task_id)
    if not task:
        return jsonify({'error': 'Task not found'}), 404

    return jsonify(task.to_dict())


@app.route('/api/tasks/<task_id>/cancel', methods=['POST'])
def cancel_task(task_id: str):
    """取消任务"""
    success = task_scheduler.cancel_task(task_id)
    if not success:
        return jsonify({'error': 'Cannot cancel task'}), 400

    event_logger.log_event('task_cancelled', f'Task {task_id} cancelled', 'api')

    return jsonify({'status': 'cancelled'})


@app.route('/api/workflows', methods=['POST'])
def create_workflow():
    """创建新工作流"""
    data = request.get_json()

    if not data:
        return jsonify({'error': 'No data provided'}), 400

    name = data.get('name', 'Unnamed Workflow')
    description = data.get('description', '')
    steps = data.get('steps', [])

    workflow = workflow_engine.create_workflow(
        name=name,
        description=description,
        steps=steps
    )

    event_logger.log_event('workflow_created',
                         f'Workflow {workflow.workflow_id} created', 'api')

    return jsonify({
        'workflow_id': workflow.workflow_id,
        'status': 'created'
    }), 201


@app.route('/api/workflows', methods=['GET'])
def list_workflows():
    """获取工作流列表"""
    status = request.args.get('status')

    if status:
        workflows = workflow_engine.get_workflows_by_status(status)
    else:
        workflows = list(workflow_engine._workflows.values())

    return jsonify({
        'workflows': [w.to_dict() if hasattr(w, 'to_dict') else w for w in workflows],
        'total': len(workflows)
    })


@app.route('/api/workflows/<workflow_id>', methods=['GET'])
def get_workflow(workflow_id: str):
    """获取工作流详情"""
    workflow = workflow_engine.get_workflow(workflow_id)
    if not workflow:
        return jsonify({'error': 'Workflow not found'}), 404

    return jsonify(workflow.to_dict())


@app.route('/api/workflows/<workflow_id>/start', methods=['POST'])
def start_workflow(workflow_id: str):
    """启动工作流"""
    data = request.get_json() or {}
    context = data.get('context', {})

    success = workflow_engine.start_workflow(workflow_id, context)
    if not success:
        return jsonify({'error': 'Cannot start workflow'}), 400

    event_logger.log_event('workflow_started',
                         f'Workflow {workflow_id} started', 'api')

    return jsonify({'status': 'started'})


@app.route('/api/workflows/<workflow_id>/pause', methods=['POST'])
def pause_workflow(workflow_id: str):
    """暂停工作流"""
    success = workflow_engine.pause_workflow(workflow_id)
    if not success:
        return jsonify({'error': 'Cannot pause workflow'}), 400

    return jsonify({'status': 'paused'})


@app.route('/api/workflows/<workflow_id>/cancel', methods=['POST'])
def cancel_workflow(workflow_id: str):
    """取消工作流"""
    success = workflow_engine.cancel_workflow(workflow_id)
    if not success:
        return jsonify({'error': 'Cannot cancel workflow'}), 400

    return jsonify({'status': 'cancelled'})


@app.route('/api/messages', methods=['POST'])
def send_message():
    """发送消息"""
    data = request.get_json()

    if not data:
        return jsonify({'error': 'No data provided'}), 400

    from core.message import Message, MessageType, MessagePriority

    receiver = data.get('receiver', '')
    msg_type_str = data.get('msg_type', 'task')
    msg_type = MessageType(msg_type_str)
    content = data.get('content', {})

    priority = data.get('priority', 2)
    if isinstance(priority, int):
        priority = MessagePriority(priority)

    msg = Message(
        msg_type=msg_type,
        sender='api',
        receiver=receiver,
        content=content,
        priority=priority
    )

    message_bus.publish(msg)

    return jsonify({
        'msg_id': msg.msg_id,
        'status': 'sent'
    }), 201


@app.route('/api/messages/<agent_id>', methods=['GET'])
def get_messages(agent_id: str):
    """获取Agent的消息"""
    limit = int(request.args.get('limit', 100))
    messages = message_bus.get_messages_for_agent(agent_id, limit)

    return jsonify({
        'messages': [m.to_dict() if hasattr(m, 'to_dict') else m for m in messages],
        'total': len(messages)
    })


@app.route('/api/state', methods=['GET'])
def get_state():
    """获取全局状态"""
    return jsonify(state_manager.get_all())


@app.route('/api/state/<key>', methods=['GET'])
def get_state_value(key: str):
    """获取状态值"""
    value = state_manager.get(key)
    if value is None:
        return jsonify({'error': 'Key not found'}), 404

    return jsonify({'key': key, 'value': value})


@app.route('/api/state/<key>', methods=['PUT'])
def set_state_value(key: str):
    """设置状态值"""
    data = request.get_json()

    if not data or 'value' not in data:
        return jsonify({'error': 'Value not provided'}), 400

    state_manager.set(key, data['value'])

    return jsonify({'key': key, 'status': 'set'})


@app.route('/api/monitor/status', methods=['GET'])
def get_monitor_status():
    """获取系统监控状态"""
    return jsonify(system_monitor.get_system_status())


@app.route('/api/monitor/metrics', methods=['GET'])
def get_metrics():
    """获取系统指标"""
    category = request.args.get('category', 'system')
    limit = int(request.args.get('limit', 100))

    metrics = system_monitor.get_metrics(category, limit)

    return jsonify({
        'category': category,
        'metrics': metrics,
        'total': len(metrics)
    })


@app.route('/api/monitor/alerts', methods=['GET'])
def get_alerts():
    """获取告警列表"""
    level = request.args.get('level')
    acknowledged = request.args.get('acknowledged')

    if level:
        from state.monitor import AlertLevel
        level = AlertLevel(level)

    if acknowledged is not None:
        acknowledged = acknowledged.lower() == 'true'

    alerts = system_monitor.get_alerts(level, acknowledged)

    return jsonify({
        'alerts': [a.to_dict() if hasattr(a, 'to_dict') else a for a in alerts],
        'total': len(alerts)
    })


@app.route('/api/monitor/alerts/<alert_id>/acknowledge', methods=['POST'])
def acknowledge_alert(alert_id: str):
    """确认告警"""
    success = system_monitor.acknowledge_alert(alert_id)
    if not success:
        return jsonify({'error': 'Alert not found'}), 404

    return jsonify({'status': 'acknowledged'})


@app.route('/api/events', methods=['GET'])
def get_events():
    """获取事件日志"""
    event_type = request.args.get('type')
    source = request.args.get('source')
    limit = int(request.args.get('limit', 100))

    events = event_logger.get_events(event_type, source, limit)

    return jsonify({
        'events': events,
        'total': len(events)
    })


@app.route('/api/statistics', methods=['GET'])
def get_statistics():
    """获取系统统计"""
    task_stats = task_scheduler.get_statistics()
    workflow_stats = workflow_engine.get_statistics()

    return jsonify({
        'tasks': task_stats,
        'workflows': workflow_stats,
        'agents': {
            'total': len(agent_registry.get_all_agents()),
            'online': len(agent_registry.get_online_agents())
        }
    })


@app.errorhandler(404)
def not_found(error):
    """404错误处理"""
    return jsonify({'error': 'Not found'}), 404


@app.errorhandler(500)
def internal_error(error):
    """500错误处理"""
    logger.error(f"Internal error: {error}")
    return jsonify({'error': 'Internal server error'}), 500


def create_api_blueprint():
    """创建API蓝图"""
    return app


def run_api_server(host: str = '0.0.0.0', port: int = 5000, debug: bool = False):
    """运行API服务器"""
    app.run(host=host, port=port, debug=debug)
