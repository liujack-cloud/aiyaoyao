"""
多Agent协同运营自动化系统 - 主程序入口
"""

import logging
import sys
from pathlib import Path

from core import config_manager, create_agent, message_bus
from core.agent import AgentState
from scheduler import task_scheduler, workflow_engine
from state import (
    agent_registry, state_manager,
    system_monitor, event_logger, performance_tracker
)
from api import socketio, setup_websocket_handlers, run_api_server
from api.websocket import (
    notify_agent_status, notify_task_update,
    notify_workflow_update, notify_alert
)


logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler('logs/agent_system.log', encoding='utf-8')
    ]
)

logger = logging.getLogger("Main")


class MultiAgentSystem:
    """多Agent协同运营自动化系统"""

    def __init__(self):
        self._agents = {}
        self._running = False
        self._setup_complete = False

    def initialize(self, config_path: str = "config.yaml") -> None:
        """初始化系统"""
        logger.info("Initializing Multi-Agent Collaboration System...")

        Path("logs").mkdir(exist_ok=True)
        Path("data").mkdir(exist_ok=True)

        config_manager.config_path = Path(config_path)
        config_manager.load_config()

        self._initialize_agents()
        self._setup_message_handlers()
        self._setup_monitor()

        task_scheduler.start()
        workflow_engine.start()

        self._running = True
        self._setup_complete = True

        logger.info("System initialization complete")

    def _initialize_agents(self) -> None:
        """初始化所有Agent"""
        agent_configs = config_manager.get_agents()

        for agent_config in agent_configs:
            agent_id = agent_config.get('id')
            try:
                agent = create_agent(agent_config)
                agent.start()

                self._agents[agent_id] = agent

                agent_registry.register_agent(
                    agent_id=agent_id,
                    agent_info={
                        'id': agent_id,
                        'name': agent_config.get('name'),
                        'type': agent_config.get('type'),
                        'state': AgentState.IDLE.value,
                        'capabilities': agent_config.get('capabilities', [])
                    }
                )

                logger.info(f"Agent initialized: {agent_id}")

            except Exception as e:
                logger.error(f"Failed to initialize agent {agent_id}: {e}")

    def _setup_message_handlers(self) -> None:
        """设置消息处理器"""
        def handle_message(message):
            if message.msg_type.value == 'result':
                task_id = message.content.get('task_id')
                if task_id:
                    task_scheduler.complete_task(task_id, message.content)
                    notify_task_update(task_id, 'completed', message.content)

            elif message.msg_type.value == 'error':
                task_id = message.content.get('task_id')
                if task_id:
                    error = message.content.get('error', 'Unknown error')
                    task_scheduler.fail_task(task_id, error)

            elif message.msg_type.value == 'heartbeat':
                agent_id = message.sender
                agent_registry.update_agent_heartbeat(agent_id)

        message_bus.subscribe('system', handle_message)

    def _setup_monitor(self) -> None:
        """设置系统监控"""
        system_monitor.start()

        def alert_callback(alert):
            notify_alert(alert.level.value, alert.message, alert.source)

        system_monitor.register_alert_callback(alert_callback)

    def start(self) -> None:
        """启动系统"""
        if not self._setup_complete:
            self.initialize()

        logger.info("Starting Multi-Agent System...")

        for agent in self._agents.values():
            agent.start()

        event_logger.log_event('system_start', 'System started', 'system')

        logger.info(f"System started with {len(self._agents)} agents")

    def stop(self) -> None:
        """停止系统"""
        logger.info("Stopping Multi-Agent System...")

        for agent in self._agents.values():
            agent.stop()

        task_scheduler.stop()
        workflow_engine.stop()
        system_monitor.stop()

        self._running = False

        event_logger.log_event('system_stop', 'System stopped', 'system')

        logger.info("System stopped")

    def get_agent(self, agent_id: str):
        """获取Agent实例"""
        return self._agents.get(agent_id)

    def get_system_status(self) -> dict:
        """获取系统状态"""
        return {
            'running': self._running,
            'agents': {
                'total': len(self._agents),
                'active': len([a for a in self._agents.values()
                             if a.state == AgentState.IDLE])
            },
            'tasks': task_scheduler.get_statistics(),
            'workflows': workflow_engine.get_statistics(),
            'system_monitor': system_monitor.get_system_status()
        }

    def create_demo_workflow(self) -> str:
        """创建演示工作流"""
        workflow = workflow_engine.create_workflow(
            name="Demo Collaboration Workflow",
            description="A demonstration workflow showing multi-agent collaboration",
            steps=[
                {
                    'step_id': 'step_1',
                    'agent': 'agent_coordinator',
                    'action': 'analyze_task',
                    'next': 'step_2'
                },
                {
                    'step_id': 'step_2',
                    'agent': 'agent_executor',
                    'action': 'execute_task',
                    'next': 'step_3'
                },
                {
                    'step_id': 'step_3',
                    'agent': 'agent_monitor',
                    'action': 'validate_result',
                    'next': 'step_4'
                },
                {
                    'step_id': 'step_4',
                    'agent': 'agent_reporter',
                    'action': 'generate_report',
                    'next': None
                }
            ]
        )

        return workflow.workflow_id

    def run_demo(self) -> None:
        """运行演示"""
        logger.info("Running demo...")

        task_id = task_scheduler.create_task(
            name="Demo Task",
            task_type="demo",
            input_data={'action': 'process', 'data': [1, 2, 3, 4, 5]}
        )
        logger.info(f"Created demo task: {task_id}")

        workflow_id = self.create_demo_workflow()
        logger.info(f"Created demo workflow: {workflow_id}")

        workflow_engine.start_workflow(workflow_id, {'demo': True})

        logger.info("Demo tasks created successfully")


system_instance = MultiAgentSystem()


def main():
    """主函数"""
    try:
        system_instance.initialize()
        system_instance.start()

        system_instance.run_demo()

        logger.info("Starting API server...")
        run_api_server(
            host=config_manager.get('server.host', '0.0.0.0'),
            port=config_manager.get('server.port', 5000),
            debug=config_manager.get('server.debug', False)
        )

    except KeyboardInterrupt:
        logger.info("Received interrupt signal")
    except Exception as e:
        logger.error(f"System error: {e}")
        raise
    finally:
        system_instance.stop()


if __name__ == "__main__":
    main()
