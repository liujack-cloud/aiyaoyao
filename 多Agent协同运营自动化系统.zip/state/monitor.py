"""
系统监控模块
监控系统运行状态、性能指标和告警管理
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, Any, Optional, List, Callable
from datetime import datetime, timedelta
import threading
import logging
import time
import psutil
import os


class AlertLevel(Enum):
    """告警级别"""
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
    CRITICAL = "critical"


class Alert:
    """告警"""
    def __init__(self, alert_id: str, level: AlertLevel, message: str,
                 source: str = "", metadata: Optional[Dict[str, Any]] = None):
        self.alert_id = alert_id
        self.level = level
        self.message = message
        self.source = source
        self.timestamp = datetime.now().isoformat()
        self.metadata = metadata or {}
        self.acknowledged = False

    def to_dict(self) -> Dict[str, Any]:
        return {
            'alert_id': self.alert_id,
            'level': self.level.value,
            'message': self.message,
            'source': self.source,
            'timestamp': self.timestamp,
            'acknowledged': self.acknowledged,
            'metadata': self.metadata
        }


class SystemMonitor:
    """系统监控器"""

    def __init__(self):
        self._running = False
        self._lock = threading.RLock()
        self._logger = logging.getLogger("SystemMonitor")
        self._alerts: List[Alert] = []
        self._metrics_history: Dict[str, List[Dict[str, Any]]] = {}
        self._max_history = 1000
        self._alert_callbacks: List[Callable] = []

    def start(self) -> None:
        """启动监控"""
        self._running = True
        self._start_monitoring()
        self._logger.info("System monitor started")

    def stop(self) -> None:
        """停止监控"""
        self._running = False
        self._logger.info("System monitor stopped")

    def _start_monitoring(self) -> None:
        """启动监控循环"""
        def monitor_loop():
            while self._running:
                self._collect_metrics()
                self._check_thresholds()
                time.sleep(10)

        thread = threading.Thread(target=monitor_loop, daemon=True)
        thread.start()

    def _collect_metrics(self) -> None:
        """收集系统指标"""
        try:
            cpu_percent = psutil.cpu_percent(interval=1)
            memory = psutil.virtual_memory()
            disk = psutil.disk_usage('/')

            metrics = {
                'timestamp': datetime.now().isoformat(),
                'cpu': {
                    'percent': cpu_percent,
                    'count': psutil.cpu_count()
                },
                'memory': {
                    'total': memory.total,
                    'available': memory.available,
                    'percent': memory.percent,
                    'used': memory.used
                },
                'disk': {
                    'total': disk.total,
                    'used': disk.used,
                    'free': disk.free,
                    'percent': disk.percent
                }
            }

            self._record_metrics('system', metrics)

        except Exception as e:
            self._logger.error(f"Failed to collect metrics: {e}")

    def _record_metrics(self, category: str, metrics: Dict[str, Any]) -> None:
        """记录指标"""
        with self._lock:
            if category not in self._metrics_history:
                self._metrics_history[category] = []

            self._metrics_history[category].append(metrics)

            if len(self._metrics_history[category]) > self._max_history:
                self._metrics_history[category] = \
                    self._metrics_history[category][-self._max_history:]

    def _check_thresholds(self) -> None:
        """检查阈值"""
        try:
            cpu = psutil.cpu_percent(interval=0.1)
            memory = psutil.virtual_memory()

            if cpu > 90:
                self.create_alert(AlertLevel.CRITICAL, f"High CPU usage: {cpu}%", "system")

            if memory.percent > 90:
                self.create_alert(AlertLevel.CRITICAL,
                                f"High memory usage: {memory.percent}%", "system")

        except Exception as e:
            self._logger.error(f"Failed to check thresholds: {e}")

    def create_alert(self, level: AlertLevel, message: str,
                    source: str = "", metadata: Optional[Dict[str, Any]] = None) -> Alert:
        """创建告警"""
        import uuid
        alert_id = str(uuid.uuid4())
        alert = Alert(alert_id, level, message, source, metadata)

        with self._lock:
            self._alerts.append(alert)

            if len(self._alerts) > self._max_history:
                self._alerts = self._alerts[-self._max_history:]

        for callback in self._alert_callbacks:
            try:
                callback(alert)
            except Exception as e:
                self._logger.error(f"Alert callback error: {e}")

        self._logger.warning(f"Alert created: [{level.value}] {message}")
        return alert

    def acknowledge_alert(self, alert_id: str) -> bool:
        """确认告警"""
        with self._lock:
            for alert in self._alerts:
                if alert.alert_id == alert_id:
                    alert.acknowledged = True
                    return True
        return False

    def get_alerts(self, level: Optional[AlertLevel] = None,
                   acknowledged: Optional[bool] = None,
                   limit: int = 100) -> List[Alert]:
        """获取告警列表"""
        with self._lock:
            alerts = self._alerts

            if level is not None:
                alerts = [a for a in alerts if a.level == level]

            if acknowledged is not None:
                alerts = [a for a in alerts if a.acknowledged == acknowledged]

            return alerts[-limit:]

    def get_metrics(self, category: str = "system", limit: int = 100) -> List[Dict[str, Any]]:
        """获取指标历史"""
        with self._lock:
            metrics = self._metrics_history.get(category, [])
            return metrics[-limit:]

    def get_current_metrics(self) -> Dict[str, Any]:
        """获取当前指标"""
        with self._lock:
            latest = {}
            for category, metrics_list in self._metrics_history.items():
                if metrics_list:
                    latest[category] = metrics_list[-1]
            return latest

    def register_alert_callback(self, callback: Callable) -> None:
        """注册告警回调"""
        self._alert_callbacks.append(callback)

    def get_system_status(self) -> Dict[str, Any]:
        """获取系统状态"""
        try:
            cpu = psutil.cpu_percent(interval=0.1)
            memory = psutil.virtual_memory()
            disk = psutil.disk_usage('/')

            status = "healthy"
            if cpu > 80 or memory.percent > 80 or disk.percent > 80:
                status = "warning"
            if cpu > 95 or memory.percent > 95 or disk.percent > 95:
                status = "critical"

            unacknowledged_alerts = len([a for a in self._alerts if not a.acknowledged])
            critical_alerts = len([a for a in self._alerts
                                   if a.level == AlertLevel.CRITICAL and not a.acknowledged])

            return {
                'status': status,
                'cpu_percent': cpu,
                'memory_percent': memory.percent,
                'disk_percent': disk.percent,
                'unacknowledged_alerts': unacknowledged_alerts,
                'critical_alerts': critical_alerts,
                'timestamp': datetime.now().isoformat()
            }

        except Exception as e:
            self._logger.error(f"Failed to get system status: {e}")
            return {
                'status': 'unknown',
                'error': str(e)
            }


class PerformanceTracker:
    """性能追踪器"""

    def __init__(self):
        self._lock = threading.RLock()
        self._operation_times: Dict[str, List[float]] = {}
        self._operation_counts: Dict[str, int] = {}
        self._max_history = 1000

    def record_operation(self, operation: str, duration: float) -> None:
        """记录操作"""
        with self._lock:
            if operation not in self._operation_times:
                self._operation_times[operation] = []
                self._operation_counts[operation] = 0

            self._operation_times[operation].append(duration)
            self._operation_counts[operation] += 1

            if len(self._operation_times[operation]) > self._max_history:
                self._operation_times[operation] = self._operation_times[operation][-self._max_history:]

    def get_statistics(self, operation: str) -> Dict[str, Any]:
        """获取操作统计"""
        with self._lock:
            times = self._operation_times.get(operation, [])
            if not times:
                return {
                    'operation': operation,
                    'count': 0,
                    'avg_time': 0,
                    'min_time': 0,
                    'max_time': 0
                }

            return {
                'operation': operation,
                'count': self._operation_counts.get(operation, 0),
                'avg_time': sum(times) / len(times),
                'min_time': min(times),
                'max_time': max(times),
                'recent_times': times[-10:]
            }

    def get_all_statistics(self) -> Dict[str, Dict[str, Any]]:
        """获取所有统计"""
        with self._lock:
            return {
                op: self.get_statistics(op)
                for op in self._operation_times.keys()
            }


class EventLogger:
    """事件日志记录器"""

    def __init__(self):
        self._events: List[Dict[str, Any]] = []
        self._lock = threading.RLock()
        self._max_events = 10000

    def log_event(self, event_type: str, message: str,
                 source: str = "", metadata: Optional[Dict[str, Any]] = None) -> None:
        """记录事件"""
        with self._lock:
            event = {
                'event_type': event_type,
                'message': message,
                'source': source,
                'timestamp': datetime.now().isoformat(),
                'metadata': metadata or {}
            }
            self._events.append(event)

            if len(self._events) > self._max_events:
                self._events = self._events[-self._max_events:]

    def get_events(self, event_type: Optional[str] = None,
                  source: Optional[str] = None,
                  limit: int = 100) -> List[Dict[str, Any]]:
        """获取事件"""
        with self._lock:
            events = self._events

            if event_type:
                events = [e for e in events if e['event_type'] == event_type]

            if source:
                events = [e for e in events if e['source'] == source]

            return events[-limit:]

    def clear_old_events(self, days: int = 7) -> int:
        """清除旧事件"""
        with self._lock:
            cutoff = datetime.now() - timedelta(days=days)
            original_count = len(self._events)

            self._events = [
                e for e in self._events
                if datetime.fromisoformat(e['timestamp']) > cutoff
            ]

            return original_count - len(self._events)


system_monitor = SystemMonitor()
performance_tracker = PerformanceTracker()
event_logger = EventLogger()
