"""
状态管理模块
管理整个多Agent系统的全局状态
"""

from dataclasses import dataclass, field
from typing import Dict, Any, Optional, List
from datetime import datetime
import threading
import logging
import json


class StateManager:
    """状态管理器"""

    def __init__(self):
        self._state: Dict[str, Any] = {}
        self._lock = threading.RLock()
        self._logger = logging.getLogger("StateManager")
        self._history: List[Dict[str, Any]] = []
        self._max_history = 500

    def get(self, key: str, default: Any = None) -> Any:
        """获取状态值"""
        with self._lock:
            return self._state.get(key, default)

    def set(self, key: str, value: Any, save_history: bool = True) -> None:
        """设置状态值"""
        with self._lock:
            old_value = self._state.get(key)
            self._state[key] = value

            if save_history and old_value != value:
                self._record_change(key, old_value, value)

    def delete(self, key: str) -> None:
        """删除状态值"""
        with self._lock:
            if key in self._state:
                del self._state[key]

    def _record_change(self, key: str, old_value: Any, new_value: Any) -> None:
        """记录状态变化"""
        change = {
            'key': key,
            'old_value': old_value,
            'new_value': new_value,
            'timestamp': datetime.now().isoformat()
        }
        self._history.append(change)

        if len(self._history) > self._max_history:
            self._history = self._history[-self._max_history:]

    def get_all(self) -> Dict[str, Any]:
        """获取所有状态"""
        with self._lock:
            return dict(self._state)

    def get_history(self, key: Optional[str] = None, limit: int = 100) -> List[Dict[str, Any]]:
        """获取状态历史"""
        with self._lock:
            if key:
                history = [h for h in self._history if h['key'] == key]
            else:
                history = self._history

            return history[-limit:]

    def clear(self) -> None:
        """清空所有状态"""
        with self._lock:
            self._state.clear()
            self._history.clear()

    def export_state(self) -> str:
        """导出状态为JSON"""
        with self._lock:
            return json.dumps({
                'state': self._state,
                'timestamp': datetime.now().isoformat()
            }, indent=2)

    def import_state(self, state_json: str) -> bool:
        """从JSON导入状态"""
        try:
            data = json.loads(state_json)
            with self._lock:
                self._state = data.get('state', {})
            return True
        except Exception as e:
            self._logger.error(f"Failed to import state: {e}")
            return False


class AgentRegistry:
    """Agent注册表"""

    def __init__(self):
        self._agents: Dict[str, Dict[str, Any]] = {}
        self._lock = threading.RLock()
        self._logger = logging.getLogger("AgentRegistry")

    def register_agent(self, agent_id: str, agent_info: Dict[str, Any]) -> None:
        """注册Agent"""
        with self._lock:
            self._agents[agent_id] = {
                **agent_info,
                'registered_at': datetime.now().isoformat(),
                'last_seen': datetime.now().isoformat()
            }
            self._logger.info(f"Agent registered: {agent_id}")

    def unregister_agent(self, agent_id: str) -> None:
        """注销Agent"""
        with self._lock:
            if agent_id in self._agents:
                del self._agents[agent_id]
                self._logger.info(f"Agent unregistered: {agent_id}")

    def update_agent_heartbeat(self, agent_id: str) -> None:
        """更新Agent心跳"""
        with self._lock:
            if agent_id in self._agents:
                self._agents[agent_id]['last_seen'] = datetime.now().isoformat()

    def get_agent(self, agent_id: str) -> Optional[Dict[str, Any]]:
        """获取Agent信息"""
        with self._lock:
            return self._agents.get(agent_id)

    def get_all_agents(self) -> List[Dict[str, Any]]:
        """获取所有Agent"""
        with self._lock:
            return list(self._agents.values())

    def get_agents_by_type(self, agent_type: str) -> List[Dict[str, Any]]:
        """按类型获取Agent"""
        with self._lock:
            return [
                agent for agent in self._agents.values()
                if agent.get('type') == agent_type
            ]

    def get_online_agents(self, timeout_seconds: int = 60) -> List[Dict[str, Any]]:
        """获取在线Agent"""
        with self._lock:
            current_time = datetime.now()
            online = []

            for agent in self._agents.values():
                last_seen = datetime.fromisoformat(agent.get('last_seen', ''))
                if (current_time - last_seen).total_seconds() < timeout_seconds:
                    online.append(agent)

            return online

    def clear(self) -> None:
        """清空注册表"""
        with self._lock:
            self._agents.clear()


class CollaborationState:
    """协作状态管理器"""

    def __init__(self):
        self._collaborations: Dict[str, Dict[str, Any]] = {}
        self._lock = threading.RLock()

    def create_collaboration(self, collab_id: str, participants: List[str],
                           metadata: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """创建协作会话"""
        with self._lock:
            collaboration = {
                'collaboration_id': collab_id,
                'participants': participants,
                'status': 'active',
                'created_at': datetime.now().isoformat(),
                'messages': [],
                'shared_state': {},
                'metadata': metadata or {}
            }
            self._collaborations[collab_id] = collaboration
            return collaboration

    def end_collaboration(self, collab_id: str) -> None:
        """结束协作会话"""
        with self._lock:
            if collab_id in self._collaborations:
                self._collaborations[collab_id]['status'] = 'ended'
                self._collaborations[collab_id]['ended_at'] = datetime.now().isoformat()

    def add_message(self, collab_id: str, sender: str, message: str) -> None:
        """添加协作消息"""
        with self._lock:
            if collab_id in self._collaborations:
                self._collaborations[collab_id]['messages'].append({
                    'sender': sender,
                    'message': message,
                    'timestamp': datetime.now().isoformat()
                })

    def update_shared_state(self, collab_id: str, key: str, value: Any) -> None:
        """更新共享状态"""
        with self._lock:
            if collab_id in self._collaborations:
                self._collaborations[collab_id]['shared_state'][key] = value

    def get_collaboration(self, collab_id: str) -> Optional[Dict[str, Any]]:
        """获取协作会话"""
        with self._lock:
            return self._collaborations.get(collab_id)

    def get_all_collaborations(self) -> List[Dict[str, Any]]:
        """获取所有协作会话"""
        with self._lock:
            return list(self._collaborations.values())


state_manager = StateManager()
agent_registry = AgentRegistry()
collaboration_state = CollaborationState()
