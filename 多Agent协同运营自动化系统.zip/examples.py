"""
使用示例 - 展示如何创建和管理多Agent协同工作流
"""

from core import config_manager, message_bus, create_agent
from core.agent import AgentState
from core.message import Message, MessageType, MessagePriority
from scheduler import task_scheduler, workflow_engine, TaskPriority
from state import agent_registry, state_manager


def example_1_basic_agent_usage():
    """示例1: 基本Agent使用"""
    print("\n=== 示例1: 基本Agent使用 ===")

    agent_config = {
        'id': 'demo_agent',
        'name': 'Demo Agent',
        'type': 'executor',
        'capabilities': ['task_execution', 'data_processing'],
        'config': {
            'max_concurrent_tasks': 3,
            'timeout': 600
        }
    }

    agent = create_agent(agent_config)
    agent.start()

    agent_info = agent_registry.get_agent('demo_agent')
    print(f"Agent registered: {agent_info}")

    agent.stop()
    print("示例1完成")


def example_2_message_communication():
    """示例2: Agent间消息通信"""
    print("\n=== 示例2: Agent间消息通信 ===")

    messages_received = []

    def on_message(message):
        messages_received.append(message)
        print(f"Received message: {message}")

    message_bus.subscribe('receiver_agent', on_message)

    msg = Message(
        msg_type=MessageType.TASK,
        sender='sender_agent',
        receiver='receiver_agent',
        content={'task': 'process_data', 'data': [1, 2, 3]},
        priority=MessagePriority.HIGH
    )

    message_bus.publish(msg)
    print(f"Message published: {msg.msg_id}")

    print(f"Total messages received: {len(messages_received)}")
    print("示例2完成")


def example_3_task_scheduling():
    """示例3: 任务调度"""
    print("\n=== 示例3: 任务调度 ===")

    task_scheduler.start()

    task_id_1 = task_scheduler.create_task(
        name="数据处理任务",
        task_type="processing",
        input_data={'operation': 'aggregate', 'data': [10, 20, 30]},
        priority=TaskPriority.HIGH,
        timeout=300
    )
    print(f"Task 1 created: {task_id_1}")

    task_id_2 = task_scheduler.create_task(
        name="分析任务",
        task_type="analysis",
        input_data={'operation': 'analyze'},
        priority=TaskPriority.NORMAL,
        timeout=600
    )
    print(f"Task 2 created: {task_id_2}")

    stats = task_scheduler.get_statistics()
    print(f"Scheduler statistics: {stats}")

    print("示例3完成")


def example_4_workflow_engine():
    """示例4: 工作流引擎"""
    print("\n=== 示例4: 工作流引擎 ===")

    workflow_engine.start()

    steps = [
        {
            'step_id': 'step_1',
            'agent': 'agent_coordinator',
            'action': 'coordinate',
            'next': 'step_2'
        },
        {
            'step_id': 'step_2',
            'agent': 'agent_executor',
            'action': 'execute',
            'next': 'step_3'
        },
        {
            'step_id': 'step_3',
            'agent': 'agent_reporter',
            'action': 'report',
            'next': None
        }
    ]

    workflow = workflow_engine.create_workflow(
        name="数据分析工作流",
        description="完整的数据分析协同工作流",
        steps=steps
    )

    print(f"Workflow created: {workflow.workflow_id}")

    workflow_engine.start_workflow(
        workflow.workflow_id,
        context={'input_data': [1, 2, 3, 4, 5]}
    )

    print(f"Workflow started: {workflow.workflow_id}")

    wf_stats = workflow_engine.get_statistics()
    print(f"Workflow statistics: {wf_stats}")

    print("示例4完成")


def example_5_state_management():
    """示例5: 状态管理"""
    print("\n=== 示例5: 状态管理 ===")

    state_manager.set('system_name', 'Multi-Agent Collaboration System')
    state_manager.set('version', '1.0.0')
    state_manager.set('active', True)

    all_state = state_manager.get_all()
    print(f"Current state: {all_state}")

    name = state_manager.get('system_name')
    print(f"System name: {name}")

    history = state_manager.get_history('system_name', limit=10)
    print(f"State history: {len(history)} entries")

    print("示例5完成")


def example_6_agent_registry():
    """示例6: Agent注册表"""
    print("\n=== 示例6: Agent注册表 ===")

    agent_registry.register_agent(
        agent_id='custom_agent_1',
        agent_info={
            'name': 'Custom Agent 1',
            'type': 'executor',
            'capabilities': ['data_processing', 'analysis']
        }
    )

    agent_registry.register_agent(
        agent_id='custom_agent_2',
        agent_info={
            'name': 'Custom Agent 2',
            'type': 'monitor',
            'capabilities': ['health_check', 'performance_monitoring']
        }
    )

    all_agents = agent_registry.get_all_agents()
    print(f"Total agents: {len(all_agents)}")

    executors = agent_registry.get_agents_by_type('executor')
    print(f"Executor agents: {len(executors)}")

    agent_registry.unregister_agent('custom_agent_1')
    remaining = agent_registry.get_all_agents()
    print(f"Remaining agents: {len(remaining)}")

    print("示例6完成")


def example_7_collaborative_workflow():
    """示例7: 完整协同工作流程"""
    print("\n=== 示例7: 完整协同工作流程 ===")

    workflow_engine.start()
    task_scheduler.start()

    workflow = workflow_engine.create_workflow(
        name="协作分析工作流",
        description="多Agent协同完成数据分析",
        steps=[
            {
                'step_id': 'collect',
                'agent': 'agent_coordinator',
                'action': 'coordinate_data_collection',
                'next': 'process'
            },
            {
                'step_id': 'process',
                'agent': 'agent_executor',
                'action': 'process_data',
                'next': 'validate'
            },
            {
                'step_id': 'validate',
                'agent': 'agent_monitor',
                'action': 'validate_results',
                'next': 'report'
            },
            {
                'step_id': 'report',
                'agent': 'agent_reporter',
                'action': 'generate_report',
                'next': None
            }
        ]
    )

    task_scheduler.create_task(
        name="分析任务",
        task_type="analysis",
        input_data={'workflow_id': workflow.workflow_id},
        priority=TaskPriority.HIGH
    )

    print(f"Created collaborative workflow: {workflow.workflow_id}")

    print("示例7完成")


def run_all_examples():
    """运行所有示例"""
    print("=" * 50)
    print("多Agent协同运营自动化系统 - 使用示例")
    print("=" * 50)

    try:
        example_1_basic_agent_usage()
        example_2_message_communication()
        example_3_task_scheduling()
        example_4_workflow_engine()
        example_5_state_management()
        example_6_agent_registry()
        example_7_collaborative_workflow()

        print("\n" + "=" * 50)
        print("所有示例执行完成!")
        print("=" * 50)

    except Exception as e:
        print(f"示例执行出错: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    run_all_examples()
