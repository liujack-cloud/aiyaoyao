# 多Agent协同运营自动化系统

## 简介

这是一个完整的多Agent协同运营自动化系统，支持：

- 多Agent创建、注册和管理
- Agent间消息通信
- 任务调度和执行
- 协同工作流引擎
- 状态管理和监控
- REST API和WebSocket接口

## 系统架构

```
┌─────────────────────────────────────────────────────────┐
│                  Multi-Agent System                     │
├─────────────────────────────────────────────────────────┤
│  ┌─────────┐  ┌─────────┐  ┌─────────┐  ┌─────────┐    │
│  │Coordinator│ │ Executor│  │ Monitor │  │ Reporter│    │
│  │  Agent   │  │  Agent   │  │  Agent   │  │  Agent   │    │
│  └────┬────┘  └────┬────┘  └────┬────┘  └────┬────┘    │
│       │            │            │            │           │
│       └────────────┴────────────┴────────────┘           │
│                         │                                │
│              ┌──────────┴──────────┐                     │
│              │    Message Bus      │                     │
│              └──────────┬──────────┘                     │
│                         │                                │
│  ┌──────────────────────┼──────────────────────┐         │
│  │                      │                      │         │
│  ▼                      ▼                      ▼         │
│ ┌──────────┐    ┌─────────────┐    ┌────────────┐      │
│ │  Task    │    │  Workflow   │    │   State    │      │
│ │ Scheduler│    │   Engine    │    │  Manager   │      │
│ └──────────┘    └─────────────┘    └────────────┘      │
│                                                          │
│  ┌─────────────────────────────────────────────┐       │
│  │              API & WebSocket                 │       │
│  └─────────────────────────────────────────────┘       │
└─────────────────────────────────────────────────────────┘
```

## 安装

```bash
pip install -r requirements.txt
```

## 快速开始

### 1. 启动系统

```bash
python main.py
```

### 2. 运行示例

```bash
python examples.py
```

## 主要模块

### Core (核心模块)

- `config.py` - 配置管理
- `message.py` - 消息和通信机制
- `agent.py` - Agent基类和实现

### Scheduler (调度模块)

- `task_scheduler.py` - 任务调度器
- `workflow_engine.py` - 协同工作流引擎

### State (状态管理模块)

- `state_manager.py` - 状态管理、Agent注册、协作状态
- `monitor.py` - 系统监控、告警管理

### API (接口层)

- `api_server.py` - REST API
- `websocket.py` - WebSocket通信

## API端点

### Agent管理

- `GET /api/agents` - 获取所有Agent
- `GET /api/agents/<agent_id>` - 获取指定Agent
- `GET /api/agents/<agent_id>/status` - 获取Agent状态

### 任务管理

- `POST /api/tasks` - 创建任务
- `GET /api/tasks` - 获取任务列表
- `GET /api/tasks/<task_id>` - 获取任务详情
- `POST /api/tasks/<task_id>/cancel` - 取消任务

### 工作流管理

- `POST /api/workflows` - 创建工作流
- `GET /api/workflows` - 获取工作流列表
- `GET /api/workflows/<workflow_id>` - 获取工作流详情
- `POST /api/workflows/<workflow_id>/start` - 启动工作流
- `POST /api/workflows/<workflow_id>/pause` - 暂停工作流
- `POST /api/workflows/<workflow_id>/cancel` - 取消工作流

### 监控管理

- `GET /api/monitor/status` - 获取系统监控状态
- `GET /api/monitor/metrics` - 获取系统指标
- `GET /api/monitor/alerts` - 获取告警列表
- `POST /api/monitor/alerts/<alert_id>/acknowledge` - 确认告警

### 状态管理

- `GET /api/state` - 获取全局状态
- `GET /api/state/<key>` - 获取状态值
- `PUT /api/state/<key>` - 设置状态值

## 配置说明

系统配置文件为 `config.yaml`，主要配置项：

- `system` - 系统基本配置
- `server` - API服务器配置
- `agents` - Agent配置列表
- `workflows` - 工作流配置
- `scheduling` - 调度器配置

## Agent类型

1. **Coordinator Agent** - 协调器，负责任务协调和工作流管理
2. **Executor Agent** - 执行器，负责具体任务执行
3. **Monitor Agent** - 监控器，负责系统监控和健康检查
4. **Reporter Agent** - 报告器，负责生成报告和通知

## 消息类型

- `TASK` - 任务消息
- `RESULT` - 结果消息
- `STATUS` - 状态消息
- `ERROR` - 错误消息
- `HEARTBEAT` - 心跳消息
- `COMMAND` - 命令消息
- `NOTIFICATION` - 通知消息
- `COORDINATION` - 协调消息

## 许可证

MIT License
